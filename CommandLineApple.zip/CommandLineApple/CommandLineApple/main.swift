//
//  main.swift
//  CommandLineApple
//
//  Created by iOS Lab on 03/02/24.
//

import Foundation

addProduct()
readProduct()
addProduct()
readProduct()
addProduct()
readProduct()

updateProduct()
readProduct()

deleteProduct()

readAll()
